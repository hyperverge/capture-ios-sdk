//
//  HyperSnapSDK.h
//  HyperSnapSDK
//
//  Created by Srinija on 06/06/18.
//  Copyright © 2018 hyperverge. All rights reserved.
//Version 2.4.11

#import <UIKit/UIKit.h>
//#import "OpenCVWrapper.h"

//! Project version number for HyperSnapSDK.
FOUNDATION_EXPORT double HyperSnapSDKVersionNumber;

//! Project version string for HyperSnapSDK.
FOUNDATION_EXPORT const unsigned char HyperSnapSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HyperSnapSDK/PublicHeader.h>


