//
//  HyperSnapSDK_Instructions.h
//  HyperSnapSDK-Instructions
//
//  Created by Srinija on 11/02/19.
//  Copyright © 2019 hyperverge. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HyperSnapSDK_Instructions.
FOUNDATION_EXPORT double HyperSnapSDK_InstructionsVersionNumber;

//! Project version string for HyperSnapSDK_Instructions.
FOUNDATION_EXPORT const unsigned char HyperSnapSDK_InstructionsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HyperSnapSDK_Instructions/PublicHeader.h>


